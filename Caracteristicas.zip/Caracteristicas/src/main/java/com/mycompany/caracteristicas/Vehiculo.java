/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.caracteristicas;

/**
 *
 * @author mcris
 */
public class Vehiculo {

    public static void main(String[] args) {
     Carro c = new Carro();
     c.setMarca("La marca es: Lamborghini");
     System.out.println(c.getMarca());
     c.setTipo("El tipo de carro es: Deportivo");
     System.out.println(c.getTipo());
     c.setMotor("El motor es: biturbo con turbocompresor V8 de 4 litros ");
     System.out.println(c.getMotor());
     c.setAño(2015);
     System.out.println(c.getAño(2015));
     c.setPrecio(103265288);
     System.out.println(c.getPrecio());
    
     
     
    
     
    }

}
