import tkinter as tk 
from PIL import Image, ImageTk

ventana = tk.Tk()
ventana.title("Inición de sesión")
marco = tk.Frame(ventana, width=100, height=100, bd=2, relief="raised")
marco.place(x=430, y=200)

marco1 =tk.Frame(ventana, width=400, height=300, bd=2, relief="raised")
marco1.place(x=800, y=200)
inicio = tk.Label(ventana, text="Inicio de sesión", width=25, font=("Arial",15))
inicio.place(x=860, y=210)
usuario = tk.Label(ventana, text="Usuario", width=25, font=("Arial", 15))
usuario.place(x=750, y=240)
ingrese_nombre = tk.Entry(ventana, width=25)
ingrese_nombre.place(x=830, y=270)
clave = tk.Label(ventana, text="Contraseña", width=25, font=("Arial",15))
clave.place(x=750, y=350)
ingrese_contraseña = tk.Entry(ventana, width=25)
ingrese_contraseña.place(x=830, y=380)
boton = tk.Button(ventana, text="Ingresar", font=("Arial",15))
boton.place(x=840, y=420)
imagen = Image.open("Logo-Tecnar (1).png")
imagen_tk = ImageTk.PhotoImage(imagen)
tamaño = (300, 300)
imagen = imagen.resize(tamaño)
imagen_tk= ImageTk.PhotoImage(imagen)
imagen_label = tk.Label(marco, image=imagen_tk, anchor="center")
imagen_label.pack()



ventana.mainloop()

