import tkinter as tk
from tkinter import messagebox
import Util.generic as utl

import json

from Formularios.Padmin import Padmin
from Formularios.Facturacion import Facturacion

class Login(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("INGRESO AL SISTEMA")
        self.resizable(False, False)
        utl.centrar_ventana(self, 800, 500)
        
        self.logo = utl.leer_imagen(r"C:\Users\mcris\OneDrive\Desktop\Parcial\Imagenes\Logo.png", (300, 100))
        self.user = utl.leer_imagen(r"C:\Users\mcris\OneDrive\Desktop\Parcial\Imagenes\login.jpeg", (48, 48))
        
        # frame_logo
        self.frame_logo = tk.Frame(self, bd=0, width=300, relief=tk.SOLID, bg='#3E4149')
        self.frame_logo.pack(side=tk.LEFT, expand=tk.YES, fill=tk.BOTH)
        self.llogo = tk.Label(self.frame_logo, image=self.logo, bg='#3E4149')
        self.llogo.pack(padx=5, pady=150)

        # frame_form
        self.frame_form = tk.Frame(self, bd=0, relief=tk.SOLID, bg='#FFFFFF')
        self.frame_form.pack(side=tk.RIGHT, expand=tk.YES, fill=tk.BOTH)
        
        self.texto = tk.Label(self.frame_form, text="INGRESO AL SISTEMA", font=('Times', 20, 'bold'), fg='#3E4149', bg='#FFFFFF')
        self.texto.pack(padx=10, pady=20)
        
        self.imglogin = tk.Label(self.frame_form, image=self.user, bg='#FFFFFF')
        self.imglogin.pack(padx=10, pady=10)
        
        self.lusuario = tk.Label(self.frame_form, text="Usuario:", font=('Times', 14), fg='#3E4149', bg='#FFFFFF')
        self.lusuario.pack(padx=10, pady=5)
        
        self.cusuario = tk.Entry(self.frame_form, width=30, font=('Times', 12), bd=2, relief=tk.GROOVE)
        self.cusuario.pack(fill=tk.X, padx=20, pady=10)
        self.cusuario.focus()

        self.lclave = tk.Label(self.frame_form, text="Clave:", font=('Times', 14), fg='#3E4149', bg='#FFFFFF')
        self.lclave.pack(padx=10, pady=5)
        
        self.cclave = tk.Entry(self.frame_form, width=30, font=('Times', 12), show="*", bd=2, relief=tk.GROOVE)
        self.cclave.pack(fill=tk.X, padx=20, pady=10)

        self.bregistrar = tk.Button(self.frame_form, text="\uf082 Iniciar sesión", font=('Times', 16, 'bold'), bg='#3E4149', fg='#FFFFFF', bd=2, relief=tk.RAISED, command=self.validar)
        self.bregistrar.pack(fill=tk.X, padx=20, pady=20)

    def validar(self):
        with open("C:\\Users\\mcris\\OneDrive\\Desktop\\Parcial\\db_user.json", "r", encoding='utf-8') as file:
            db_users = json.load(file)
        if self.cusuario.get() == "" and self.cclave.get() == "":
            messagebox.showerror('Error', "Debes llenar los campos de Usuario / Contraseña", parent=self)
            self.cusuario.focus()
        else:
            for usuarios in db_users["users"]:
                if self.cusuario.get() == usuarios["username"] and self.cclave.get() == usuarios["password"] and usuarios["role"] == "Administrador":
                    self.destroy()
                    Padmin(usuarios["name"], usuarios["username"], usuarios["email"]).mainloop()
                elif self.cusuario.get() == usuarios["username"] and self.cclave.get() == usuarios["password"] and usuarios["role"] == "Vendedor":
                    self.destroy()
                    Facturacion(usuarios["name"], usuarios["username"], usuarios["email"]).mainloop()
            messagebox.showerror('Error', "Usuario / Contraseña errados", parent=self)
