import tkinter as tk
import json
from tkinter import messagebox, ttk

import Util.generic as utl
from PIL import Image, ImageTk
class Facturacion(tk.Tk):
    def __init__(self, name="", username="", email=""):
        self.name = name
        self.username = username
        self.email = email
        self.tipo_action = "Guardar"
        self.tipo_user = ""
        super().__init__()
        self.title("Panel Ventas")
        self.resizable(False, False)

        # Obtener las dimensiones de la pantalla
        self.ancho_pantalla = self.winfo_screenwidth()
        self.alto_pantalla = self.winfo_screenheight()

        # Establecer el tamaño completo de la ventana
        self.geometry(f"{self.ancho_pantalla}x{self.alto_pantalla}")
        
        menubar = tk.Menu(self)

        menuclientes = tk.Menu(menubar, tearoff=0)
        menuclientes.add_command(label="Confirmación de reservas", command=self.main_facturacion)
        menubar.add_cascade(label="Reservas", menu=menuclientes)


        self.config(menu=menubar)

        # frame user_info
        self.frame_user_info = tk.Frame(self, bd=0, relief=tk.SOLID, width=200, bg='#3E4149')
        self.frame_user_info.pack(side=tk.LEFT, padx=4, pady=5, fill="y")
        texto = tk.Label(self.frame_user_info, text="Panel de Ventas", font=('Times', 20, 'bold'), fg='#FFFFFF', bg='#3E4149')
        texto.pack(padx=20, pady=10)

        # frame_data
        self.frame_data = tk.Frame(self, bd=0, relief=tk.SOLID, width=self.ancho_pantalla - 200, bg='#FFFFFF')
        self.frame_data.pack(side=tk.RIGHT, padx=4, pady=5, fill="both", expand=1)
        textobienvenida = tk.Label(self.frame_data, text="BIENVENIDO AL SISTEMA", font=('Times', 20, 'bold'), fg='#3E4149', bg='#FFFFFF')
        textobienvenida.pack(padx=20, pady=10)

        # frame_dinamyc
        self.frame_dinamyc = tk.Frame(self.frame_data, bd=0, relief=tk.SOLID, width=self.ancho_pantalla - 200, bg='#FFFFFF')
        self.frame_dinamyc.pack(side=tk.RIGHT, padx=4, pady=5, fill="both", expand=1)

    def main_facturacion(self):
        self.formulario_facturacion()
        self.listar_facturacion()

    def formulario_facturacion(self):
        self.limpiar_panel(self.frame_dinamyc)
        labelform = tk.Label(self.frame_dinamyc, text="\uf0c9 REGISTRO DE USUARIOS", font=('Times', 16), fg="#9fa8da", bg='#FFFFFF')
        labelform.place(x=70, y=30)
        
        labelcedula = tk.Label(self.frame_dinamyc, text="Cédula:", font=('Times', 14), bg='#FFFFFF')
        labelcedula.place(x=70, y=100)
        self.ccedula = tk.Entry(self.frame_dinamyc, width=40, font=('Times', 12))
        self.ccedula.place(x=220, y=100)

        labelnombre = tk.Label(self.frame_dinamyc, text="Nombre completo:", font=('Times', 14), bg='#FFFFFF')
        labelnombre.place(x=70, y=130)
        self.cnombre = tk.Entry(self.frame_dinamyc, width=40, font=('Times', 12))
        self.cnombre.place(x=220, y=130)

        labelusuario = tk.Label(self.frame_dinamyc, text="Username:", font=('Times', 14), bg='#FFFFFF')
        labelusuario.place(x=70, y=160)
        self.cusuario = tk.Entry(self.frame_dinamyc, width=40, font=('Times', 12))
        self.cusuario.place(x=220, y=160)

        labelclave = tk.Label(self.frame_dinamyc, text="Contraseña:", font=('Times', 14), bg='#FFFFFF')
        labelclave.place(x=500, y=100)
        self.cclave = tk.Entry(self.frame_dinamyc, width=40, show="*", font=('Times', 12))
        self.cclave.place(x=600, y=100)

        labelcorreo = tk.Label(self.frame_dinamyc, text="Correo:", font=('Times', 14), bg='#FFFFFF')
        labelcorreo.place(x=500, y=130)
        self.ccorreo = tk.Entry(self.frame_dinamyc, width=40, font=('Times', 12))
        self.ccorreo.place(x=600, y=130)

        labeltipo = tk.Label(self.frame_dinamyc, text="Rol:", font=('Times', 14), bg='#FFFFFF')
        labeltipo.place(x=500, y=160)
        self.listatipo = tk.Listbox(self.frame_dinamyc, selectmode="single", width=40, height=2, font=('Times', 12))
        self.listatipo.place(x=600, y=160)
        self.listatipo.insert(1, "Administrador")
        self.listatipo.insert(2, "Vendedor")

        btnguardar = tk.Button(self.frame_dinamyc, text="\uf0c7 GUARDAR", font=('Times', 14), bg='#3E4149', fg='#FFFFFF', command=self.save_facturacion)
        btnguardar.place(x=870, y=130)

    def listar_facturacion(self):
        tk.Label(self.frame_dinamyc, text="\uf00b LISTADO DE USUARIOS", font=('Times', 16), fg="#9fa8da", bg='#FFFFFF').place(x=70, y=200)
        self.tablausuarios = ttk.Treeview(self.frame_dinamyc, columns=("NombreCompleto", "Username", "Email", "Rol"))
        self.tablausuarios.heading("#0", text="Cédula")
        self.tablausuarios.heading("NombreCompleto", text="Nombre Completo")
        self.tablausuarios.heading("Username", text="Usuario")
        self.tablausuarios.heading("Email", text="Email")
        self.tablausuarios.heading("Rol", text="Rol")
        
        with open("C:\\Users\\mcris\\OneDrive\\Desktop\\Parcial\\data\\db_facturacion.json", "r", encoding='utf-8') as self.file:
            self.db_facturacion = json.load(self.file)
            for usuarios in self.db_facturacion["facturacion"]:
                self.tablausuarios.insert("", "end", text=f'{usuarios["id"]}', values=(f'{usuarios["name"]}', f'{usuarios["username"]}', f'{usuarios["email"]}', f'{usuarios["role"]}'))
        
        self.tablausuarios.place(x=70, y=250)
        btneliminar = tk.Button(self.frame_dinamyc, text="\uf0c7 Eliminar", font=('Times', 14), bg='#d9534f', fg='#FFFFFF', command=self.delete_facturacion)
        btneliminar.place(x=70, y=520)
        btnupdate = tk.Button(self.frame_dinamyc, text="\uf0c7 Actualizar", font=('Times', 14), bg='#5bc0de', fg='#FFFFFF', command=self.update_facturacion)
        btnupdate.place(x=200, y=520)

    def save_facturacion(self):
        for index in self.listatipo.curselection():
            self.tipo_user = self.listatipo.get(index)
        if self.ccedula.get() =="" or self.cnombre.get() == "" or self.cusuario.get() == "" or self.ccorreo.get() == "" or self.cclave.get() == "" or self.tipo_user == "":
            messagebox.showinfo('Info',"Debe llenar todos los campos",parent=self)
            return 
        else:
                with open("C:\\Users\\mcris\\OneDrive\\Desktop\\Parcial\\data\\db_facturacion.json", "r", encoding='utf-8') as self.file:
                        self.db_facturacion = json.load(self.file)

                        if self.tipo_action == "Actualizar":

                            for usuarios in self.db_facturacion["facturacion"]:
                                if usuarios["id"] == self.tablausuarios.item(self.tablausuarios.selection())["text"]:
                                    usuarios["id"] = self.ccedula.get()
                                    usuarios["name"] = self.cnombre.get()
                                    usuarios["username"] = self.cusuario.get()
                                    usuarios["password"] =  self.cclave.get()
                                    usuarios["email"] = self.ccorreo.get()
                                    usuarios["role"] = self.tipo_user
                                    with open('C:\\Users\\mcris\\OneDrive\\Desktop\\Parcial\\data\\db_facturacion.json', 'w') as jf: 
                                        json.dump(self.db_facturacion, jf, indent=4, ensure_ascii=True)
                                        messagebox.showinfo('Info',"Usuario actualizado con exito",parent=self)
                                        #self.listar_usuarios()
                                        self.limpiar_panel(self.frame_dinamyc)
                    
                        else:
                            self.db_facturacion["facturacion"].append({
                                            'id': self.ccedula.get(),
                                            'name': self.cnombre.get(),
                                            'username': self.cusuario.get(),
                                            'password': self.cclave.get(),
                                            'email': self.ccorreo.get(),
                                            'role':self.tipo_user
                                            })
                            with open('C:\\Users\\mcris\\OneDrive\\Desktop\\Parcial\\data\\db_facturacion.json', 'w') as jf: 
                                json.dump(self.db_facturacion, jf, indent=4, ensure_ascii=True)
                                messagebox.showinfo('Info',"Usuario registrado con exito",parent=self)
                                self.limpiar_panel(self.frame_dinamyc)
    def delete_facturacion(self):
        with open("C:\\Users\\mcris\\OneDrive\\Desktop\\Parcial\\data\\db_facturacion.json", "r", encoding='utf-8') as self.file:
                self.db_facturacion = json.load(self.file)
                for usuarios in self.db_facturacion["facturacion"]:
                    if usuarios["id"] == self.tablausuarios.item(self.tablausuarios.selection())["text"]:
                        self.db_facturacion["facturacion"].remove(usuarios)
                        with open('C:\\Users\\mcris\\OneDrive\\Desktop\\Parcial\\data\\db_facturacion.json', 'w') as jf:
                            json.dump(self.db_facturacion, jf, indent=4, ensure_ascii=True)
                            messagebox.showinfo('Info',"Usuario eliminado con exito",parent=self)
                            self.limpiar_panel(self.frame_dinamyc)
                            break



    def update_facturacion(self):
        with open("C:\\Users\\mcris\\OneDrive\\Desktop\\Parcial\\data\\db_facturacion.json", "r", encoding='utf-8') as self.file:
                self.db_facturacion = json.load(self.file)
                
                seleccion = self.tablausuarios.selection()

                if seleccion:

                    for item in seleccion:
                        item = self.tablausuarios.index(item)
                        
                        self.ccedula.delete(0, tk.END)
                        self.ccedula.insert(0, self.db_facturacion["facturacion"][item]["id"])

                        self.cnombre.delete(0, tk.END)
                        self.cnombre.insert(0, self.db_facturacion["facturacion"][item]["name"])

                        self.cusuario.delete(0, tk.END)
                        self.cusuario.insert(0, self.db_facturacion["facturacion"][item]["username"])
                        
                        self.cclave.delete(0, tk.END)
                        self.cclave.insert(0,self.db_facturacion["facturacion"][item]["password"])
                        
                        self.ccorreo.delete(0, tk.END)
                        self.ccorreo.insert(0,self.db_facturacion["facturacion"][item]["email"])

                        self.tipo_action = "Actualizar"
                        break
                                                
    def limpiar_panel(self,panel):
    # Función para limpiar el contenido del panel
        for widget in panel.winfo_children():
            widget.destroy()
            