Persona = ["jesus","david","19"]

class Personass:
    def __init__(self, crearp, listarp, eliminarp):
        self.crearp = crearp
        self.listarp = listarp
        self.eliminarp = eliminarp
    def crear_persona(self):
        Nombre = input("Escribir el nombre de la persona: ")
        Persona.insert(0,Nombre)
    def Listar_persona(self):
        print(Persona)
    def Eliminar_persona(self):
        Eliminar = input("Escriba el nombre que quiere eliminar: ")
        Persona.remove(Eliminar)
        
universidade = ["Tecnar", "Sinu","Unicolombo","Los libertadores","Utb","Udc"] 

class universidades:
    def __init__(self, crear, listar, eliminar):
        self.crear = crear
        self.listar = listar
        self.eliminar = eliminar
    def crear_universidad(self):
        crearu = input("Nombre de la universidad: ")
        universidade.append(crearu)
    def listar_unirsidades(self):
        print(universidade)
    def eliminar_universidad(self):
        eliminar2 = input("Escriba la universidad que quiere eliminar: ")
        universidade.remove(eliminar2)
nota = ["4","3","3","2","Total"]        
class notas:
    def __init__(self, crear, listar, eliminar):
        self.crear = crear
        self.listar = listar
        self.eliminar = eliminar
    def crear_nota(self):
        agregar_nota = input("Escriba la nota que desea agregar: ")
        nota.append(agregar_nota)
    def listar_notas(self):
        print(nota)
    def eliminar_nota(self):
        eliminar_nota = input("Escriba la nota que desea eliminar: ")
        nota.remove(eliminar_nota)
        
Asignaturas = ["castellano","matematicas","sociales","filosofia"]

class Asignatu:
    def __init__(self, crear, listar, eliminar):
        self.crear = crear
        self.listar = listar
        self.eliminar = eliminar
    def crear_asignatura(self):
        agregar_asignatura = input("Escriba la asignatura que desea agregar: ")
        Asignaturas.append(agregar_asignatura)
    def listar_asignatura(self):
        print(Asignaturas)
    def eliminar_asignatura(self):
        eliminar_asignatura = input("Escriba la asignatura que desea eliminar: ")
        Asignaturas.remove(eliminar_asignatura)
        
  