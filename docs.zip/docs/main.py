from Personas import Persona
from Personas import Personass
from Personas import universidade
from Personas import universidades
from Personas import nota
from Personas import notas
from Personas import Asignatu
from Personas import Asignaturas


while True:
        print("MENU PRINCIPAL")
        print("Escoge una de las opciones")
        print("1. Personas")
        print("2. Universidades")
        print("3. Notas")
        print("4. Asignaturas")
        print("5. Salir")
        
        menupersona = Personass(True, True, True)
        menuuniversidad = universidades(True,True,True)
        menunotas = notas(True,True,True)
        menuasignaturas = Asignatu(True,True,True)

        escoger = int(input("Tu opción: "))

        if escoger == 1:
                while(True):
                        print("SUB MENU: ")
                        print("Escoge una de las opciones: ")
                        print("Crear persona == 1")
                        print("listar persona == 2")
                        print("eliminar una persona == 3")
                        print("devolverte == 4")
                
                        subopcion = int(input("Escoja la opcion: "))
                        if subopcion == 1:
                                menupersona.crear_persona()
                                print(Persona)
                        if subopcion == 2:
                                menupersona.Listar_persona()
                               
                        if subopcion == 3:
                                menupersona.Eliminar_persona()
                                print(Persona)
                        if subopcion == 4:
                                break
        
        if escoger == 2:
                while(True):
                        print("Sub menu: ")
                        print("Escoge una de las opciones: ")
                        print("Crear universidad == 1")
                        print("listar universidad == 2")
                        print("eliminar una universidad == 3")
                        print("devolverte == 4")
                
                        subopcion = int(input("Escoja la opcion: "))
                        if subopcion == 1:
                                menuuniversidad.crear_universidad()
                                print(universidade)
                        if subopcion == 2:
                                menuuniversidad.listar_unirsidades()
                               
                        if subopcion == 3:
                                menuuniversidad.eliminar_universidad()
                                print(universidade)
                        if subopcion == 4:
                                break
        if escoger == 3:
                while(True):
                        print("Sub menu: ")
                        print("Escoge una de las opciones: ")
                        print("Crear nota == 1")
                        print("listar notas == 2")
                        print("eliminar una nota == 3")
                        print("devolverte == 4")
                
                        subopcion = int(input("Escoja la opcion: "))
                        if subopcion == 1:
                                menunotas.crear_nota()
                                print(nota)
                        if subopcion == 2:
                                menunotas.listar_notas()
                                
                        if subopcion == 3:
                                menunotas.eliminar_nota()
                                print(nota)
                        if subopcion == 4:
                                break
        
        if escoger == 4:
                while(True):
                        print("Sub menu: ")
                        print("Escoge una de las opciones: ")
                        print("Crear asignatura == 1")
                        print("listar asignaturas == 2")
                        print("eliminar una asignatura == 3")
                        print("devolverte == 4")
                
                        subopcion = int(input("Escoja la opcion: "))
                        if subopcion == 1:
                                menuasignaturas.crear_asignatura()
                                print(Asignaturas)
                        if subopcion == 2:
                                menuasignaturas.listar_asignatura()
                                
                        if subopcion == 3:
                                menuasignaturas.eliminar_asignatura()
                                print(Asignaturas)
                        if subopcion == 4:
                                break
        if escoger == 5:
                break

        else:
             print("ingrese una opcion valida")
          
        
      